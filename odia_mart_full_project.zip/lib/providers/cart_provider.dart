import 'package:flutter/material.dart';
import '../models/product.dart';

class CartProvider with ChangeNotifier {
  final Map<String, int> _items = {};
  final Map<String, Product> _products = {};

  Map<String,int> get items => Map.unmodifiable(_items);

  double get total {
    double s = 0;
    for (var pid in _items.keys) {
      final qty = _items[pid]!;
      final p = _products[pid]!;
      s += p.price * qty;
    }
    return s;
  }

  void addProduct(Product p) {
    _products[p.id] = p;
    _items[p.id] = (_items[p.id] ?? 0) + 1;
    notifyListeners();
  }

  void removeOne(String id) {
    if (!_items.containsKey(id)) return;
    final v = _items[id]!;
    if (v <= 1) _items.remove(id);
    else _items[id] = v - 1;
    notifyListeners();
  }

  void removeAll(String id) {
    _items.remove(id);
    _products.remove(id);
    notifyListeners();
  }

  void clear() {
    _items.clear();
    _products.clear();
    notifyListeners();
  }

  List<Map<String, dynamic>> get cartDetails {
    final list = <Map<String, dynamic>>[];
    for (var id in _items.keys) {
      list.add({'product': _products[id]!, 'qty': _items[id]!});
    }
    return list;
  }
}
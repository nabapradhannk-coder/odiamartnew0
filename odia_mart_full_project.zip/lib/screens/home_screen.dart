import 'package:flutter/material.dart';
import '../models/product.dart';
import 'product_detail.dart';
import 'package:provider/provider.dart';
import '../providers/cart_provider.dart';
import 'cart_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  List<Product> fakeProducts() {
    return [
      Product(id: 'p1', name: 'Mango 1kg', description: 'Fresh Alphonso mangoes', price: 120, image: ''),
      Product(id: 'p2', name: 'Dog Food 1kg', description: 'Complete nutrition for dogs', price: 299, image: ''),
      Product(id: 'p3', name: 'Milk 1L', description: 'Pure dairy milk', price: 45, image: ''),
      Product(id: 'p4', name: 'Bread', description: 'Fresh bread loaf', price: 40, image: ''),
      Product(id: 'p5', name: 'Eggs (6)', description: 'Farm eggs', price: 60, image: ''),
      Product(id: 'p6', name: 'Chips', description: 'Crunchy potato chips', price: 30, image: ''),
    ];
  }

  @override
  Widget build(BuildContext context) {
    final products = fakeProducts();
    final cart = Provider.of<CartProvider>(context, listen: false);
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal:14.0, vertical:12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const SizedBox(height:8),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: const [
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Odia Mart', style: TextStyle(color: Color(0xFF4B8F6B), fontSize:12)),
              SizedBox(height:4),
              Text('12 minutes', style: TextStyle(fontSize:28, fontWeight: FontWeight.w800, color: Color(0xFF0F7A4F))),
            ]),
            Icon(Icons.person, size:36, color: Color(0xFF0B7A55))
          ]),
          const SizedBox(height:12),
          Container(
            padding: const EdgeInsets.symmetric(horizontal:12, vertical:8),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12)),
            child: Row(children: const [Icon(Icons.search), SizedBox(width:8), Expanded(child: Text('Search here Mango', style: TextStyle(color: Colors.grey))), Icon(Icons.mic)]),
          ),
          const SizedBox(height:12),
          const Text('Products', style: TextStyle(fontSize:18,fontWeight: FontWeight.w700)),
          const SizedBox(height:10),
          Expanded(
            child: GridView.builder(
              itemCount: products.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:2, crossAxisSpacing:12, mainAxisSpacing:12, childAspectRatio:0.78),
              itemBuilder: (c,i){
                final p = products[i];
                return Card(
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  elevation:2,
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Expanded(child: Center(child: Text('🧺', style: TextStyle(fontSize:44)))),
                      const SizedBox(height:8),
                      Text(p.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                      const SizedBox(height:4),
                      Text('₹${p.price.toStringAsFixed(0)}', style: const TextStyle(color: Colors.black87)),
                      const SizedBox(height:6),
                      Row(children: [
                        Expanded(child: OutlinedButton(onPressed: (){ cart.addProduct(p); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Added to cart'))); }, child: const Text('Add'))),
                        const SizedBox(width:8),
                        ElevatedButton(onPressed: (){ cart.addProduct(p); Navigator.of(context).push(MaterialPageRoute(builder: (_) => const CartScreen())); }, child: const Text('Buy')),
                      ])
                    ]),
                  ),
                );
              }
            ),
          )
        ]),
      ),
    );
  }
}
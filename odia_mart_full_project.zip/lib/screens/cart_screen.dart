import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/cart_provider.dart';

class CartScreen extends StatelessWidget {
  const CartScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final cart = Provider.of<CartProvider>(context);
    final items = cart.cartDetails;
    return Scaffold(
      appBar: AppBar(title: const Text('Your Cart'), backgroundColor: const Color(0xFF0B7A55)),
      body: items.isEmpty ? const Center(child: Text('🛒 Your cart is empty!')) :
      Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(children: [
          Expanded(child: ListView.separated(
            itemCount: items.length,
            separatorBuilder: (_,__) => const Divider(),
            itemBuilder: (c,i){
              final p = items[i]['product'];
              final qty = items[i]['qty'];
              return ListTile(
                leading: const Text('🧺', style: TextStyle(fontSize:28)),
                title: Text(p.name),
                subtitle: Text('Qty: $qty  •  ₹${(p.price*qty).toStringAsFixed(0)}'),
                trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                  IconButton(icon: const Icon(Icons.remove_circle_outline), onPressed: () => cart.removeOne(p.id)),
                  IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => cart.removeAll(p.id)),
                ]),
              );
            }
          )),
          const SizedBox(height:8),
          Text('Total: ₹${cart.total.toStringAsFixed(0)}', style: const TextStyle(fontSize:18,fontWeight: FontWeight.w700)),
          const SizedBox(height:8),
          ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF0B7A55)), onPressed: (){
            final total = cart.total;
            cart.clear();
            showDialog(context: context, builder: (ctx) => AlertDialog(title: const Text('Order placed'), content: Text('Your order of ₹${total.toStringAsFixed(0)} has been placed.'), actions: [TextButton(onPressed: () => Navigator.of(ctx).pop(), child: const Text('OK'))]));
          }, child: const Padding(padding: EdgeInsets.symmetric(horizontal:24,vertical:12), child: Text('Checkout'))),
        ]),
      ),
    );
  }
}
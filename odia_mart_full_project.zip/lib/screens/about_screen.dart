import 'package:flutter/material.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: const [
            Icon(Icons.store, size: 88, color: Color(0xFF0B7A55)),
            SizedBox(height:16),
            Text('Odia Mart', style: TextStyle(fontSize:22, fontWeight: FontWeight.w700)),
            SizedBox(height:8),
            Text('Demo app with local fake products. Use CodeMagic or flutter build to create APK.'),
          ]),
        ),
      ),
    );
  }
}
import 'package:flutter/material.dart';
import '../models/product.dart';
import 'package:provider/provider.dart';
import '../providers/cart_provider.dart';

class ProductDetail extends StatelessWidget {
  final Product product;
  const ProductDetail({required this.product, super.key});

  @override
  Widget build(BuildContext context) {
    final cart = Provider.of<CartProvider>(context, listen: false);
    return Scaffold(
      appBar: AppBar(title: Text(product.name), backgroundColor: const Color(0xFF0B7A55)),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(children: [
          Expanded(child: Center(child: Text('🧺', style: TextStyle(fontSize:80)))),
          const SizedBox(height:12),
          Text(product.name, style: const TextStyle(fontSize:22,fontWeight: FontWeight.w700)),
          const SizedBox(height:8),
          Text(product.description),
          const SizedBox(height:12),
          Text('₹${product.price.toStringAsFixed(0)}', style: const TextStyle(fontSize:18,fontWeight: FontWeight.w700)),
          const SizedBox(height:12),
          ElevatedButton(onPressed: (){ cart.addProduct(product); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Added to cart'))); }, child: const Padding(padding: EdgeInsets.symmetric(horizontal:20,vertical:12), child: Text('Add to Cart'))),
        ]),
      ),
    );
  }
}